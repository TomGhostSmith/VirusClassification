from prototype.moduleConfig import ModuleConfig

class MergeConfig(ModuleConfig):
    def __init__(self, models):
        self.models = models