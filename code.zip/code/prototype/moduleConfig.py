class ModuleConfig():
    def __init__(self):
        self.name = None

    # update its name, which will be used as model's module name
    def update(self):
        pass